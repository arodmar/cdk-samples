import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigw from 'aws-cdk-lib/aws-apigateway';
import { HitCounter } from './hitcounter';


export class CdkWorkshopStack extends cdk.Stack {
  constructor(scope: cdk.App, id: string, props?:cdk.StackProps) {
    super(scope, id, props);

    const hello = new lambda.Function(this, 'HelloHandler', {
      runtime: lambda.Runtime.NODEJS_16_X,
      code: lambda.Code.fromAsset('lambda'),
      handler:'hello.handler',
      functionName: 'Hello' 
    });

    const helloWithCounter = new HitCounter(this, 'HelloHitCounter', {
      downstream: hello,
      constructName: 'HitCounter'
    });

    const apil = new apigw.LambdaRestApi(this, 'Endpoint-LambdaRestApi',{
      handler: helloWithCounter.handler,
      
    })

    const apiDefinition = new apigw.RestApi(this, 'ApiDefinition',{
      restApiName:'cdkapidefinitiontest'
    });
    const versionResource = apiDefinition.root.addResource('v1');
    const resourceTest = versionResource.addResource('resource-test');
    resourceTest.addMethod('GET', new apigw.LambdaIntegration(hello))
  }
}
